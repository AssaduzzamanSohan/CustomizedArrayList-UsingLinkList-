package Sohan_Day_13.CustomizedArrayList;

import java.awt.List;
import java.util.ArrayList;

public class App 
{
    public static void main( String[] args )
    {
    	StudentArrayList<Student> studentList = new StudentArrayList();

 		Student st1 = new Student("Sohan", "1", 25);
 		Student st2 = new Student("Tonmoy", "2", 21);
 		Student st3 = new Student("Shaila", "3", 22);
 		Student st4 = new Student("Rana", "4", 24);

 		
 		studentList.add(st1);
 		studentList.add(st2);
 		studentList.add(st3);
 		studentList.add(st4);
 	
 		studentList.remove(2);

 		studentList.show();
    }
}
