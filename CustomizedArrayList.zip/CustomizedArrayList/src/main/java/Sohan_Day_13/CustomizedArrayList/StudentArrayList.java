package Sohan_Day_13.CustomizedArrayList;

public class StudentArrayList<T>{
	private Node head = null; // The first Node.
	private Node position = null; // How many nodes are in the list

	class Node {
		T element;
		Node next;
	}

	boolean add(T element) {
		if (head == null) {
			position = new Node();
			position.element = element;
			position.next = null;
			head = position;

		} else {
			position.next = new Node();
			position = position.next;
			position.element = element;
			position.next = null;
		}
		return true;

	}

	void add(int index, T element) {
		if (head == null) {
			position = new Node();
			position.element = element;
			position.next = null;
			head = position;
		} else if (index == 1) {
			position = new Node();
			position.element = element;
			position.next = head;
			head = position;
		}

		else {
			Node previous = findPreviousNode(index);
			position = new Node();
			position.element = element;
			position.next = previous.next;
			previous.next = position;
		}
	}

	boolean remove(T element) {
		position = head;

		if (position.element == element) {
			head = head.next;
			return true;
		}

		while (position.next.element != element) {
			position = position.next;
		}
		Node found = position.next;
		position.next = found.next;
		return true;
	}

	T remove(int index) {
		if (index == 1) {
			head = head.next;
			return head.element;
		}

		Node previous = findPreviousNode(index);

		Node found = previous.next;
		previous.next = found.next;

		return found.next.element;

	}

	T set(int index, T element) {
		if (index == 1) {
			head.element = element;
			return head.element;
		}

		Node previous = findPreviousNode(index);

		Node found = previous.next;
		found.element = element;

		return found.element;
	}

	T get(int index) {
		if (index == 1)
			return head.element;
		return findPreviousNode(index).next.element;
	}

	int size() {
		int count = 0;
		position = head;
		while (position != null) {
			count++;
			position = position.next;
		}

		return count;
	}


	void show() {
		position = head;
		while (position != null) {
			System.out.println(position.element);
			position = position.next;
		}

	}

	private Node findPreviousNode(int index) {
		position = head;
		for (int i = 1; i <= index - 2; i++) {
			position = position.next;
		}
		return position;
	}
}
